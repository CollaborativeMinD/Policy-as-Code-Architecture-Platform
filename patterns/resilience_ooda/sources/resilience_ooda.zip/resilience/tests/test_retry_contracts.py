"""Scoped invariant tests. Simulation verifies local contract, not upstream library ABI."""
import ast
import asyncio
from pathlib import Path
import pytest

CONFIGS=Path(__file__).resolve().parents[1]/'core_example_configs'
NAMES=['tenacity_basic_retry','tenacity_stopping_conditions','tenacity_waiting_strategies','tenacity_filtering_errors','tenacity_logging_hooks','tenacity_retry_async_code']

@pytest.mark.parametrize('name',NAMES)
def test_syntax_and_no_import_side_effects(name):
    src=(CONFIGS/(name+'.py')).read_text()
    tree=ast.parse(src)
    assert not any(isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='basicConfig' for n in ast.walk(tree))
    assert not any(isinstance(n,ast.Import) and any(alias.name=='requests' for alias in n.names) for n in ast.walk(tree))

@pytest.mark.parametrize('name',NAMES)
def test_no_unbounded_retry_decorator(name):
    tree=ast.parse((CONFIGS/(name+'.py')).read_text())
    for fn in [x for x in ast.walk(tree) if isinstance(x,(ast.FunctionDef,ast.AsyncFunctionDef))]:
        for dec in fn.decorator_list:
            if isinstance(dec,ast.Call) and isinstance(dec.func,ast.Name) and dec.func.id=='retry':
                assert any(k.arg=='stop' for k in dec.keywords),fn.name
                assert any(k.arg=='retry' for k in dec.keywords),fn.name

@pytest.mark.parametrize('failures,expected',[(0,1),(1,2),(2,3)])
def test_basic_transient_recovery(simulated_tenacity,failures,expected):
    load,state,_=simulated_tenacity
    m=load('tenacity_basic_retry'); counter=0
    def connection():
        nonlocal counter
        counter+=1
        if counter<=failures: raise ConnectionError('temporary')
        return 'ready'
    assert m.unreliable_network_call(connection)=='ready'
    assert counter==expected

@pytest.mark.parametrize('error',[ValueError,PermissionError,TypeError])
def test_basic_permanent_errors_not_retried(simulated_tenacity,error):
    load,state,_=simulated_tenacity
    m=load('tenacity_basic_retry'); n=0
    def operation():
        nonlocal n
        n+=1; raise error()
    with pytest.raises(error): m.unreliable_network_call(operation)
    assert n==1

def test_basic_exhaustion_propagates(simulated_tenacity):
    load,state,_=simulated_tenacity
    m=load('tenacity_basic_retry');n=0
    def broken():
        nonlocal n
        n+=1;raise ConnectionError('offline')
    with pytest.raises(ConnectionError):m.unreliable_network_call(broken)
    assert n==3

@pytest.mark.parametrize('name,maximum', [('try_three_times',3),('combined_stop',5)])
def test_bounded_stopping(simulated_tenacity,name,maximum):
    load,state,_=simulated_tenacity
    m=load('tenacity_stopping_conditions');n=0
    def failed():
        nonlocal n
        n+=1;raise ConnectionError('offline')
    with pytest.raises(ConnectionError):getattr(m,name)(failed)
    assert 1<=n<=maximum

@pytest.mark.parametrize('name,expected', [('wait_two_seconds',[2,2]),('random_wait',[2,2]),('api_call_with_backoff',[2,2])])
def test_wait_strategy_and_bounded_retries(simulated_tenacity,name,expected):
    load,state,_=simulated_tenacity
    m=load('tenacity_waiting_strategies')
    with pytest.raises(ConnectionError):getattr(m,name)(lambda: (_ for _ in ()).throw(ConnectionError()))
    assert state.sleeps==expected

@pytest.mark.parametrize('name',[ 'fetch_api_data', 'find_user_session'])
def test_filtered_transient_success(simulated_tenacity,name):
    load,state,_=simulated_tenacity
    m=load('tenacity_filtering_errors');n=0
    def operation():
        nonlocal n
        n+=1
        if n<3:
            if name=='fetch_api_data':raise ConnectionError()
            return None
        return 'ok'
    assert getattr(m,name)(operation)=='ok'
    assert n==3

def test_filtered_non_retryable_error(simulated_tenacity):
    load,state,_=simulated_tenacity
    m=load('tenacity_filtering_errors');n=0
    def invalid():
        nonlocal n
        n+=1;raise ValueError('bad request')
    with pytest.raises(ValueError):m.fetch_api_data(invalid)
    assert n==1

def test_none_result_is_bounded(simulated_tenacity):
    load,state,RetryError=simulated_tenacity
    m=load('tenacity_filtering_errors');n=0
    def missing():
        nonlocal n
        n+=1;return None
    with pytest.raises(RetryError):m.find_user_session(missing)
    assert n==3

def test_logging_before_sleep_only(simulated_tenacity,caplog):
    load,state,_=simulated_tenacity
    m=load('tenacity_logging_hooks')
    with caplog.at_level('WARNING'):
        with pytest.raises(ValueError):m.logged_operation(lambda: (_ for _ in ()).throw(ValueError('failed')))
    assert len([r for r in caplog.records if r.levelname=='WARNING'])==2

def test_async_recovery_and_bound(simulated_tenacity):
    load,state,_=simulated_tenacity
    m=load('tenacity_retry_async_code');n=0
    async def flaky():
        nonlocal n
        n+=1
        if n<3:raise ConnectionError('transient')
        return 'ok'
    assert asyncio.run(m.retry_async_operation(flaky))=='ok'
    assert n==3

@pytest.mark.parametrize('error',[ValueError,PermissionError])
def test_async_fatal_error_no_retry(simulated_tenacity,error):
    load,state,_=simulated_tenacity
    m=load('tenacity_retry_async_code');n=0
    async def invalid():
        nonlocal n
        n+=1;raise error('fatal')
    with pytest.raises(error):asyncio.run(m.retry_async_operation(invalid))
    assert n==1

@pytest.mark.parametrize('is_async',[False,True])
def test_inline_blocks_bounded(simulated_tenacity,is_async):
    load,state,_=simulated_tenacity
    m=load('tenacity_retry_async_code');n=0
    def bad():
        nonlocal n
        n+=1;raise ConnectionError()
    if is_async:
        async def bad_async():bad()
        with pytest.raises(ConnectionError):asyncio.run(m.retry_async_block(bad_async))
    else:
        with pytest.raises(ConnectionError):m.retry_inline_block(bad)
    assert n==3

@pytest.mark.parametrize('name', ['retry_inline_block','retry_async_block'])
def test_inline_transient_recovery(simulated_tenacity,name):
    load,state,_=simulated_tenacity
    m=load('tenacity_retry_async_code'); n=0
    def operation():
        nonlocal n
        n+=1
        if n<3:raise ConnectionError('temporary')
        return 'recovered'
    if name=='retry_async_block':
        async def async_operation():return operation()
        assert asyncio.run(m.retry_async_block(async_operation))=='recovered'
    else:
        assert m.retry_inline_block(operation)=='recovered'
    assert n==3

@pytest.mark.parametrize('name', ['retry_inline_block','retry_async_block'])
def test_inline_permanent_error_not_retried(simulated_tenacity,name):
    load,state,_=simulated_tenacity
    m=load('tenacity_retry_async_code');n=0
    def invalid():
        nonlocal n
        n+=1
        raise PermissionError('denied')
    if name=='retry_async_block':
        async def async_invalid():invalid()
        with pytest.raises(PermissionError):asyncio.run(m.retry_async_block(async_invalid))
    else:
        with pytest.raises(PermissionError):m.retry_inline_block(invalid)
    assert n==1

@pytest.mark.parametrize('name',['wait_two_seconds','random_wait','api_call_with_backoff'])
def test_non_retryable_errors_skip_wait(simulated_tenacity,name):
    load,state,_=simulated_tenacity
    m=load('tenacity_waiting_strategies');n=0
    def operation():
        nonlocal n
        n+=1;raise ValueError('invalid input')
    with pytest.raises(ValueError):getattr(m,name)(operation)
    assert n==1 and state.sleeps==[]

@pytest.mark.parametrize('name',NAMES)
def test_no_ambient_io_or_process_effects(name):
    tree=ast.parse((CONFIGS/(name+'.py')).read_text())
    forbidden={'subprocess','socket','os','pathlib','requests'}
    for node in ast.walk(tree):
        if isinstance(node,ast.Import):
            assert not any(a.name.split('.')[0] in forbidden for a in node.names)
        if isinstance(node,ast.ImportFrom):
            assert (node.module or '').split('.')[0] not in forbidden


def test_tenacity_installed_for_upstream_integration():
    """Separate gate: live upstream package is required for compatibility qualification."""
    import importlib.util
    if importlib.util.find_spec('tenacity') is None:
        pytest.skip('HOLD: Tenacity distribution not installed; upstream integration unverified')
    assert importlib.util.find_spec('tenacity') is not None
