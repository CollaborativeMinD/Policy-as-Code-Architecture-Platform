"""Deterministic retry-contract simulator, not a Tenacity compatibility substitute."""
import importlib
import inspect
import sys
import types
from pathlib import Path
import pytest

CONFIG_DIR = Path(__file__).resolve().parents[1] / 'core_example_configs'

@pytest.fixture
def simulated_tenacity(monkeypatch):
    state = types.SimpleNamespace(events=[], sleeps=[], calls=[])
    class RetryError(Exception): pass
    class Attempt:
        def __init__(self, number): self.retry_state = types.SimpleNamespace(attempt_number=number); self.error=None
        def __enter__(self): return self
        def __exit__(self, typ, value, tb):
            self.error=value
            return typ is not None
    def stop_after_attempt(n):
        assert n > 0
        return lambda number: number >= n
    def stop_after_delay(sec):
        assert sec >= 0
        return lambda number: number > 1 and (number - 1) >= sec
    class Stop:
        def __init__(self, fn): self.fn=fn
        def __call__(self, n): return self.fn(n)
        def __or__(self, other): return Stop(lambda n: self(n) or other(n))
    def wait_fixed(n): return lambda n_attempt: n
    def wait_random(min, max): return lambda n_attempt: (min + max) / 2
    def wait_exponential(multiplier=1, min=0, max=1e20):
        return lambda n_attempt: builtins_min(max, builtins_max(min, multiplier * (2 ** (n_attempt - 1))))
    builtins_min, builtins_max = __import__('builtins').min, __import__('builtins').max
    def retry_if_exception_type(exc_type): return lambda exc, result: isinstance(exc, exc_type)
    def retry_if_result(predicate): return lambda exc, result: exc is None and predicate(result)
    def before_sleep_log(logger, level):
        return lambda retry_state: logger.log(level, 'Retrying attempt %d', retry_state.attempt_number)
    def retry(*, stop=None, retry=None, wait=None, reraise=False, before_sleep=None):
        def wrap(func):
            async def async_wrapper(*args, **kwargs):
                return await run(func, args, kwargs, True)
            def sync_wrapper(*args, **kwargs):
                return run_sync(func, args, kwargs)
            async def run(func, args, kwargs, is_async):
                for num in range(1, 30):
                    state.calls.append((func.__name__, num))
                    try:
                        result = await func(*args, **kwargs)
                        exc = None
                    except Exception as e:
                        result, exc = None, e
                    again = retry(exc, result) if retry else exc is not None
                    if not again:
                        if exc is not None: raise exc
                        return result
                    if (stop or (lambda n: False))(num):
                        if exc is not None and reraise: raise exc
                        raise RetryError('exhausted')
                    if before_sleep: before_sleep(types.SimpleNamespace(attempt_number=num))
                    state.sleeps.append(wait(num) if wait else 0)
                raise AssertionError('unbounded retry')
            def run_sync(func, args, kwargs):
                for num in range(1, 30):
                    state.calls.append((func.__name__, num))
                    try:
                        result=func(*args, **kwargs); exc=None
                    except Exception as e:
                        result, exc=None, e
                    again = retry(exc,result) if retry else exc is not None
                    if not again:
                        if exc is not None: raise exc
                        return result
                    if (stop or (lambda n: False))(num):
                        if exc is not None and reraise: raise exc
                        raise RetryError('exhausted')
                    if before_sleep: before_sleep(types.SimpleNamespace(attempt_number=num))
                    state.sleeps.append(wait(num) if wait else 0)
                raise AssertionError('unbounded retry')
            wrapper=async_wrapper if inspect.iscoroutinefunction(func) else sync_wrapper
            wrapper.retry_contract=dict(stop=stop, retry=retry, wait=wait)
            return wrapper
        return wrap
    class Retrying:
        def __init__(self, *, stop, retry=None, reraise=False): self.stop=stop; self.retry=retry; self.reraise=reraise
        def __iter__(self):
            for i in range(1,30):
                state.calls.append(('inline',i))
                attempt=Attempt(i)
                yield attempt
                if attempt.error is None: return
                if self.retry is not None and not self.retry(attempt.error,None): raise attempt.error
                if self.stop(i):
                    if self.reraise: raise attempt.error
                    raise RetryError('exhausted')
            raise AssertionError('unbounded')
    class AsyncRetrying(Retrying):
        async def __aiter__(self):
            for a in self:
                yield a
    fake=types.ModuleType('tenacity')
    fake.__dict__.update(dict(retry=retry,stop_after_attempt=lambda n:Stop(stop_after_attempt(n)),stop_after_delay=lambda n:Stop(stop_after_delay(n)),wait_fixed=wait_fixed,wait_random=wait_random,wait_exponential=wait_exponential,retry_if_exception_type=retry_if_exception_type,retry_if_result=retry_if_result,before_sleep_log=before_sleep_log,Retrying=Retrying,AsyncRetrying=AsyncRetrying,RetryError=RetryError))
    monkeypatch.setitem(sys.modules,'tenacity',fake)
    def load(name):
        unique='contract_test_'+name
        sys.modules.pop(unique,None)
        spec=importlib.util.spec_from_file_location(unique, CONFIG_DIR / (name+'.py'))
        module=importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        return module
    return load,state,RetryError
