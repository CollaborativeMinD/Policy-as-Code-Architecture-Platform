"""Run directly with the target interpreter and installed Tenacity."""
import importlib.metadata
from pathlib import Path
import sys
from time import sleep, monotonic_ns
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "core_example_configs"))
import tenacity_stopping_conditions as gate

S = 1_000_000_000


def denied(operation, reason, attempts, **kwargs):
    try:
        gate.try_for_ten_seconds(operation, **kwargs)
    except gate.RetryWindowClosed as exc:
        assert (exc.receipt.reason, exc.receipt.attempts) == (reason, attempts)
        return exc.receipt
    raise AssertionError("Expected a clamp receipt")


def forbidden():
    raise AssertionError("Dispatch must be denied")


print(sys.version.split()[0], importlib.metadata.version("tenacity"))
with patch.object(gate, "monotonic_ns", return_value=S):
    receipt = denied(forbidden, "insufficient_margin", 0,
                     attempt_bound_ns=9*S, fallback_reserve_ns=S)
    assert receipt.required_ns == receipt.deadline_ns - receipt.observed_ns
    assert gate.try_for_ten_seconds(lambda: 42, attempt_bound_ns=9*S-1,
                                    fallback_reserve_ns=S) == 42
    denied(forbidden, "invalid_time_evidence", 0, attempt_bound_ns=S,
           fallback_reserve_ns=S, violation_deadline_ns=lambda: None)
    def transient():
        raise ConnectionError
    evidence = iter([9*S, 9*S, 9*S, 2*S])
    denied(transient, "insufficient_margin", 1, attempt_bound_ns=S,
           fallback_reserve_ns=S, violation_deadline_ns=lambda: next(evidence))
    denied(transient, "insufficient_margin", 1, attempt_bound_ns=8*S,
           fallback_reserve_ns=S)
    calls = []
    def recover():
        calls.append(1)
        if len(calls) == 1:
            raise ConnectionError
        return 42
    assert gate.try_for_ten_seconds(recover, attempt_bound_ns=S,
                                    fallback_reserve_ns=S) == 42

def overrun():
    sleep(.03)
    return 42

denied(overrun, "attempt_bound_exceeded", 1,
       attempt_bound_ns=10_000_000, fallback_reserve_ns=S)

def slow_failure():
    sleep(.65)
    raise ConnectionError

started = monotonic_ns()
receipt = denied(slow_failure, "insufficient_margin", 6,
                 attempt_bound_ns=750_000_000, fallback_reserve_ns=100_000_000)
elapsed = (monotonic_ns() - started) / S
assert elapsed < 9.9
print(f"8 live checks passed. Six attempts, clamp at {elapsed:.3f} s.")
