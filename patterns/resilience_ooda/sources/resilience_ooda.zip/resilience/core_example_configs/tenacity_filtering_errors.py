"""Separate transient exception and missing-result retry policies.

No assumption is made about HTTP response status; callers must validate it.
"""
from collections.abc import Callable
from typing import Optional, TypeVar
from tenacity import retry, retry_if_exception_type, retry_if_result, stop_after_attempt, wait_fixed

T = TypeVar('T')

@retry(stop=stop_after_attempt(3), retry=retry_if_exception_type(ConnectionError), wait=wait_fixed(0), reraise=True)
def fetch_api_data(fetch: Callable[[], T]) -> T:
    """Only ConnectionError is retryable; client errors pass through."""
    return fetch()

@retry(stop=stop_after_attempt(3), retry=retry_if_result(lambda value: value is None), wait=wait_fixed(0))
def find_user_session(lookup: Callable[[], Optional[T]]) -> Optional[T]:
    """On repeated None, Tenacity raises RetryError after three calls."""
    return lookup()
