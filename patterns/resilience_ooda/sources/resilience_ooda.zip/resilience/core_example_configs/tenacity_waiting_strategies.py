"""Finite wait strategies; no network requests or time spent on import."""
from collections.abc import Callable
from typing import TypeVar
from tenacity import retry, retry_if_exception_type, stop_after_attempt, wait_fixed, wait_random, wait_exponential

T = TypeVar('T')

@retry(stop=stop_after_attempt(3), retry=retry_if_exception_type(ConnectionError), wait=wait_fixed(2), reraise=True)
def wait_two_seconds(operation: Callable[[], T]) -> T:
    return operation()

@retry(stop=stop_after_attempt(3), retry=retry_if_exception_type(ConnectionError), wait=wait_random(min=1, max=3), reraise=True)
def random_wait(operation: Callable[[], T]) -> T:
    return operation()

@retry(stop=stop_after_attempt(3), retry=retry_if_exception_type(ConnectionError), wait=wait_exponential(multiplier=1, min=2, max=10), reraise=True)
def api_call_with_backoff(operation: Callable[[], T]) -> T:
    return operation()
