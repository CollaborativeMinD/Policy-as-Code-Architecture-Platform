"""Bounded retry for transient connection failures only.

The original indefinite retry was not admissible for a finite recovery contract.
Terminal failure is surfaced to the caller; the caller owns PACE escalation.
"""
from collections.abc import Callable
from typing import TypeVar
from tenacity import retry, retry_if_exception_type, stop_after_attempt, wait_fixed

T = TypeVar('T')

@retry(stop=stop_after_attempt(3), retry=retry_if_exception_type(ConnectionError),
       wait=wait_fixed(0), reraise=True)
def unreliable_network_call(open_connection: Callable[[], T]) -> T:
    """Invoke an injected connection once per attempt; at most three attempts."""
    return open_connection()
