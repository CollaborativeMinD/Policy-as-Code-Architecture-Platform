"""Finite asyncio decorator and inline block retry examples.

Retry only ConnectionError and delegate exhausted retries to the caller.
"""
from collections.abc import Awaitable, Callable
from typing import TypeVar
from tenacity import AsyncRetrying, Retrying, retry, retry_if_exception_type, stop_after_attempt, wait_fixed

T = TypeVar('T')

@retry(stop=stop_after_attempt(3), retry=retry_if_exception_type(ConnectionError), wait=wait_fixed(0), reraise=True)
async def retry_async_operation(operation: Callable[[], Awaitable[T]]) -> T:
    return await operation()

def retry_inline_block(operation: Callable[[], T]) -> T:
    for attempt in Retrying(stop=stop_after_attempt(3), retry=retry_if_exception_type(ConnectionError), reraise=True):
        with attempt:
            return operation()
    raise AssertionError('unreachable')

async def retry_async_block(operation: Callable[[], Awaitable[T]]) -> T:
    async for attempt in AsyncRetrying(stop=stop_after_attempt(3), retry=retry_if_exception_type(ConnectionError), reraise=True):
        with attempt:
            return await operation()
    raise AssertionError('unreachable')
