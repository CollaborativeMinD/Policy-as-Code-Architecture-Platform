"""Three finite stopping contracts with caller-supplied operations."""
from collections.abc import Callable
from dataclasses import dataclass
from math import ceil, isfinite
from time import monotonic_ns
from typing import TypeVar
from tenacity import retry, retry_if_exception_type, stop_after_attempt, stop_after_delay, wait_fixed

T = TypeVar('T')

@retry(stop=stop_after_attempt(3), retry=retry_if_exception_type(ConnectionError), wait=wait_fixed(0), reraise=True)
def try_three_times(operation: Callable[[], T]) -> T:
    return operation()

@dataclass(frozen=True)
class DeadlineReceipt:
    reason: str
    attempts: int
    observed_ns: int
    deadline_ns: int
    required_ns: int


class RetryWindowClosed(TimeoutError):
    def __init__(self, receipt: DeadlineReceipt):
        self.receipt = receipt
        super().__init__(receipt.reason)


def try_for_ten_seconds(
    operation: Callable[[], T],
    *,
    attempt_bound_ns: int,
    fallback_reserve_ns: int,
    uncertainty_ns: int = 0,
    violation_deadline_ns: Callable[[], int] | None = None,
) -> T:
    """Retry within a strict monotonic budget. Bounds are caller-qualified.

    An optional listener supplies a fresh absolute violation deadline in the
    same monotonic clock domain. Each valid reading can tighten this call's
    deadline. The callback must return promptly. A clamp raises a receipt for
    caller handoff. Synchronous callbacks cannot be interrupted here.
    """
    deadline = monotonic_ns() + 10_000_000_000
    if any(type(value) is not int or value < 0 for value in
           (attempt_bound_ns, fallback_reserve_ns, uncertainty_ns)):
        raise ValueError("Timing bounds must be nonnegative integer nanoseconds")
    if attempt_bound_ns == 0:
        raise ValueError("Attempt bound must be positive")

    attempts = 0
    reserve = fallback_reserve_ns + uncertainty_ns

    def clamp(reason: str, now: int, required: int) -> None:
        raise RetryWindowClosed(
            DeadlineReceipt(reason, attempts, now, deadline, required)
        )

    def admit(required: int) -> None:
        nonlocal deadline
        if violation_deadline_ns is not None:
            try:
                candidate = violation_deadline_ns()
                if type(candidate) is not int:
                    raise ValueError("Expected monotonic nanoseconds")
            except Exception as exc:
                raise RetryWindowClosed(DeadlineReceipt(
                    "invalid_time_evidence", attempts, monotonic_ns(), deadline, required
                )) from exc
            deadline = min(deadline, candidate)
        now = monotonic_ns()
        if required >= deadline - now:
            clamp("insufficient_margin", now, required)

    def before_sleep(state) -> None:
        delay = state.next_action.sleep
        admit(ceil(delay * 1_000_000_000) + attempt_bound_ns + reserve)

    @retry(stop=stop_after_attempt(11), retry=retry_if_exception_type(ConnectionError),
           wait=wait_fixed(1), before_sleep=before_sleep, reraise=True)
    def guarded_attempt() -> T:
        nonlocal attempts
        admit(attempt_bound_ns + reserve)
        attempts += 1
        started = monotonic_ns()
        try:
            return operation()
        finally:
            now = monotonic_ns()
            if now - started > attempt_bound_ns:
                clamp("attempt_bound_exceeded", now, attempt_bound_ns + reserve)
            admit(reserve)

    return guarded_attempt()


@retry(stop=(stop_after_attempt(5) | stop_after_delay(20)), retry=retry_if_exception_type(ConnectionError), wait=wait_fixed(0), reraise=True)
def combined_stop(operation: Callable[[], T]) -> T:
    return operation()
