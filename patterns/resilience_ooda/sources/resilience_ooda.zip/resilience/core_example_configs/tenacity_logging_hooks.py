"""Log only before a scheduled retry; never alter global logging settings."""
import logging
from collections.abc import Callable
from typing import TypeVar
from tenacity import before_sleep_log, retry, retry_if_exception_type, stop_after_attempt, wait_fixed

T = TypeVar('T')
logger = logging.getLogger(__name__)

@retry(stop=stop_after_attempt(3), retry=retry_if_exception_type(ValueError),
       wait=wait_fixed(0), before_sleep=before_sleep_log(logger, logging.WARNING), reraise=True)
def logged_operation(operation: Callable[[], T]) -> T:
    """ValueError is retryable only in this demonstrative contract."""
    return operation()
