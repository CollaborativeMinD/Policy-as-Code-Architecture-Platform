# Reconciliation and scoped qualification record

**Baseline:** uploaded `resilience.zip` (six illustrative Tenacity files and one readme). **Implementation:** bounded, injectable retry operations. **Scope:** behavior contracts only; no infrastructure, deployable runtime, network, or live state effects.

**Observed defects in scaffold:** undefined `open_connection()`, indefinitely retrying decorators, non-idempotency risk from unqualified arbitrary exception retries, retry on all exceptions, unbounded result retries, HTTP call bound to a public endpoint, import-time global logging changes, an unbounded inline example, and async prose without coroutine behavior. One file name had an accidental whitespace suffix.

**Remediation:** inject callbacks, normalize the file name, add explicit finite stop guards and recoverable error filters, preserve separate fixed/random/exponential waiting patterns and logging hook, add working async and inline definitions, and eliminate import-time execution and network dependencies. Defaults are examples rather than mission-authorized values.

**Tests:** deterministic isolated simulator unit and parameterized pytest fixtures, AST/static isolation checks, negative paths, and external-dependency presence gate. These check local contract logic only. Source-validation is **not** a proof of compatibility with Tenacity itself.

**HOLD — upstream integration:** Required witness: actual installed Tenacity running these bases and real-library unit tests. Release condition: install and pin Tenacity, run verified behavior tests, and capture library version/hash. Current tool environment lacks Tenacity and cannot reach a package index.

**HOLD — deployment and operational admission:** Required witnesses: target platform, authorized runtime resources, fault taxonomy, PACE transitions and substituted-service guarantees, state/acknowledgment reconciliation, thresholds and units, idempotency evidence, and designated operator authorization. These are not defined by the scaffold. No deployment was attempted.

**Recovery guidance:** Propagated `ConnectionError`/`ValueError` and exhausted `RetryError` are caller-visible. Freeze further governed effects, record attempts and uncertain acknowledgments, validate authority/epoch and external state, then apply the target-authorized fallback or Terminal policy. A restart requires separate authorized admission.

## OODA software retry slice

The timed example requires qualified attempt and fallback bounds in integer nanoseconds. Its optional TTV listener supplies a conservative absolute deadline in the local monotonic clock domain. The caller owns freshness, conversion, and listener latency. Attempt admission requires a sum strictly below remaining time. The gate checks before sleeping, immediately before dispatch, and before returning an outcome. A rejected continuation raises RetryWindowClosed with an immutable receipt for caller escalation. Other examples retain their policies.

**VV-007–012 — live software gate passed.** See TEST_EVIDENCE.md. The upstream installation HOLD for this slice is superseded for the tested build.

**HOLD — absolute handoff and deployment.** A synchronous callback, listener, or scheduler may exceed its assumed bound. The gate detects an attempt overrun after control returns. It cannot force cancellation or undo an issued effect. Closing this HOLD requires qualified target bounds or an independently enforced timeout and evidence that fallback and effect reconciliation meet the target deadline.
