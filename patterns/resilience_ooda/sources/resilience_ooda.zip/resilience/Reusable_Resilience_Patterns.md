# Tenacity — Reconciled Resilience Bases

Scope: six independent Python retry examples. Their authority is restricted to invocation of a **caller-supplied operation**. No network, process, filesystem, or state mutation is authorized by importing a base. Effects performed by callbacks remain the caller's responsibility.

Dependency: `tenacity` (Apache-2.0); install explicitly with `python -m pip install tenacity`. The tests in `tests/test_retry_contracts.py` use an isolated deterministic contract simulator for local behavior validation. They do **not** establish compatibility with a real Tenacity distribution. Run the integration qualification with the declared dependency before operational promotion.

| Base | Contract | Retry selection | Stop/terminal behavior |
|---|---|---|---|
| `tenacity_basic_retry.py` | Injected connection callable | `ConnectionError` only | <= 3 attempts; final exception propagates |
| `tenacity_stopping_conditions.py` | Three bounded stop policies | `ConnectionError` only | attempt limit, strict 10-second admission window with an 11-attempt cap, or 5-attempt-or-20-second limit |
| `tenacity_waiting_strategies.py` | Fixed, random, and capped exponential waits | `ConnectionError` only | <= 3 attempts; final exception propagates |
| `tenacity_filtering_errors.py` | Exception or missing-result filters | `ConnectionError` or `None`, respectively | <= 3; final exception or `RetryError` for `None` |
| `tenacity_logging_hooks.py` | Warn before next scheduled retry | demonstrative `ValueError` | <= 3; no global logging configuration |
| `tenacity_retry_async_code.py` | Coroutine and sync/async inline examples | `ConnectionError` only | <= 3; final exception propagates |

## Usage

```python
from core_example_configs.tenacity_basic_retry import unreliable_network_call

# A callback must be idempotent or externally guarded before retries are allowed.
connection = unreliable_network_call(lambda: establish_connection())
```

## Required integration/release checks

1. Install a versioned Tenacity distribution in an isolated runtime and lock the resolved version and distribution digest. Run `python -m pytest tests -q` without injecting the simulator into production code.
2. Verify real-library retry behavior, exception identity, elapsed-time stop, `RetryError` semantics, async iteration, and before-sleep records in that target environment; replay relevant regressions.
3. Confirm operation idempotency, effect admission, caller authority, resource budget, time units, and thresholds against the target mission contract. All retry thresholds in this package are **illustrative**, not mission-qualified.
4. When the budget is exhausted, stop attempts and surface the error. The caller must independently decide Primary/Alternate/Contingency/Emergency selection, Terminal conditions, and any restart authorization. Do not turn a failure into a silent success.
5. Reconcile uncertain acknowledgments, partial commits, and epochs **before** retrying mutable effects. `RetryError` is not evidence of a safe rollback.

## Non-claims

No live network access, availability guarantee, recovery time objective, idempotency guarantee, real Tenacity runtime verification, package lock, production admission, or PACE transition qualification is demonstrated by this example bundle. No operationally authorized thresholds, mission environment, or immutable request snapshots were supplied. Preserve this HOLD at integration and deployment gates without blocking scoped software-level examples.
