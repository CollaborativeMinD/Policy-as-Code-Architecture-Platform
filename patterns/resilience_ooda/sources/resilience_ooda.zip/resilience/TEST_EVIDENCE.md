# Test evidence

- Date (UTC): 2026-11-14T20:18:47.387649+00:00
- Changed surface: six Python examples, scoped fixtures, tests, docs, manifest
- Command: `PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 python -m pytest resilience/tests -q`
- Result: **48 passed, 1 skipped** (upstream Tenacity distribution unavailable)
- Command: `python -m compileall -q resilience/core_example_configs resilience/tests`
- Result: **PASS**
- Command: `python -m pip install tenacity -q`
- Result: **FAILED**, package index DNS/network unavailable; this is an environment dependency HOLD, not a demonstrated library defect
- Tests updated first: **yes**; initial failing tests were created before implementation; then rerun after changes
- Generated artifacts: `MANIFEST.sha256.json`, `TEST_EVIDENCE.md`, reconciled archive, archive SHA-256 sidecar
- Non-claims: simulator-only behavior tests cannot establish upstream compatibility, resource viability, deployment admission, or operational recovery guarantees
- Changes applied only within config contract; no real services, infrastructure, or operational state accessed

## Strict OODA admission delta

- Command: `/usr/bin/python3 tests/live_deadline.py`
- Runtime: Python 3.13.5, installed Tenacity 8.4.2+really8.4.1.
- Eight checks passed: equality denial, one-nanosecond margin admission, invalid evidence, deadline tightening after backoff, denial before backoff, transient recovery, callback overrun, and real-clock clamp.
- Real-clock trace: six 650 ms failing callbacks, one-second backoff, 750 ms admitted attempt bound, 100 ms fallback reserve. Clamp receipt at 8.906 s. Baseline had started a seventh attempt and returned at 10.556 s.
- Prior pytest suite was not rerun in this environment because pytest was unavailable. The prior timed simulator case was replaced by the live checks above.
